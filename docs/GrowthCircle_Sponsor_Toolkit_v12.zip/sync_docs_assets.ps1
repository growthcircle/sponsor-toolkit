param(
  [string]$RepoPath = "C:\Users\devuser\Sponsor_Toolkit"
)

Push-Location $RepoPath

$src = $RepoPath
$dst = Join-Path $src "docs"

$filesToSync = @(
  # Branding
  "Branding\logo.png",
  "Branding\logo.svg",
  "Branding\logo_horizontal.png",
  "Branding\logo@2x.png",
  "Branding\logo_favicon.ico",
  "Branding\logo_print.eps",
  "Branding\logo_3d_animated.webp",

  # Pitch Deck
  "Pitch_Deck\Growth_Circle_Sponsor_Deck.pdf",

  # Flyers
  "Branded_Flyers\GC_QR_Flyer_Portrait.pdf",
  "Branded_Flyers\GC_QR_Flyer_WhiteLabel.pdf",
  "Branded_Flyers\QR_Preview_PNGs\qr_Portrait.png",
  "Branded_Flyers\QR_Preview_PNGs\qr_Animated.webp",

  # Full ZIP
  "GrowthCircle_Sponsor_Toolkit.zip"
)

foreach ($rel in $filesToSync) {
  $fullSrc = Join-Path $src $rel
  $fullDst = Join-Path $dst $rel

  # Create the target folder if needed
  New-Item -ItemType Directory -Force -Path (Split-Path $fullDst) | Out-Null

  # Copy it
  Copy-Item -Path $fullSrc -Destination $fullDst -Force
}

# Commit & push
git add docs
git commit -m "Sync all real assets into docs for GitHub Pages"
git push origin master

Pop-Location
