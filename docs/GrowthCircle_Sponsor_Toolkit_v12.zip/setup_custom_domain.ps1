param (
  [string]$RepoPath = "C:\Users\devuser\Sponsor_Toolkit",
  [string]$CustomDomain = "toolkit.growthcircle.io"
)

Push-Location $RepoPath

# Step 1: Create docs/CNAME with your custom domain
$CnamePath = Join-Path $RepoPath "docs\CNAME"
Set-Content -Path $CnamePath -Value $CustomDomain

# Step 2: Commit and push
git add docs/CNAME
git commit -m "Add custom domain CNAME for GitHub Pages"
git push origin master

Pop-Location

Write-Host "`n✅ CNAME file committed and pushed."
Write-Host "📌 Now visit your domain registrar and add this DNS record:"
Write-Host "`nType:     CNAME"
Write-Host "Name:     toolkit"
Write-Host "Value:    growthcircle.github.io"
Write-Host "`nOnce DNS propagates (~5–30 min), your site will resolve at:"
Write-Host "🔗 https://$CustomDomain`n"
Write-Host "👉 Then go to https://github.com/growthcircle/sponsor-toolkit → Settings → Pages"
Write-Host "✅ Set custom domain to: $CustomDomain"
Write-Host "✅ Enable 'Enforce HTTPS'"
