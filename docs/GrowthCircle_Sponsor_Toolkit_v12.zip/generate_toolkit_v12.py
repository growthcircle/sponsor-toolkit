#!/usr/bin/env python3
"""
generate_toolkit_v12.py

Bundles the entire Sponsor_Toolkit repo (minus excluded paths) 
into a versioned ZIP for easy sponsor download.
"""

import argparse
import logging
import sys
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

# Configure logger
logging.basicConfig(level=logging.INFO, format="%(message)s")
log = logging.getLogger("toolkit_zipper")


def bundle_toolkit(source_dir: Path, output_zip: Path, excludes: list[Path]) -> None:
    """
    Walk source_dir recursively, excluding any path
    that starts with one of the exclude roots, and write
    all files into the output_zip preserving relative paths.
    """
    if output_zip.exists():
        log.info(f"🧹 Removing old ZIP: {output_zip}")
        output_zip.unlink()

    all_files = []
    for path in source_dir.rglob("*"):
        # Skip directories and excluded paths
        if path.is_dir():
            continue
        if any(str(path).startswith(str(exc)) for exc in excludes):
            log.debug(f"Skipping excluded: {path}")
            continue
        # Skip hidden files/directories
        if any(part.startswith(".") for part in path.relative_to(source_dir).parts):
            log.debug(f"Skipping hidden: {path}")
            continue
        all_files.append(path)

    log.info(f"📦 Creating ZIP at {output_zip}")
    with ZipFile(output_zip, "w", compression=ZIP_DEFLATED) as zf:
        for file_path in all_files:
            rel_path = file_path.relative_to(source_dir)
            log.info(f"  + Adding: {rel_path}")
            zf.write(file_path, arcname=rel_path)

    log.info(f"\n✅ ZIP created: {output_zip} ({output_zip.stat().st_size // 1024} KB, {len(all_files)} files)")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate GrowthCircle Sponsor Toolkit ZIP (v12)."
    )
    parser.add_argument(
        "--source", "-s",
        type=Path,
        default=Path("."),
        help="Root folder of Sponsor_Toolkit to bundle (default: current dir)"
    )
    parser.add_argument(
        "--output", "-o",
        type=Path,
        default=Path("docs/GrowthCircle_Sponsor_Toolkit_v12.zip"),
        help="Destination path for the ZIP (default: docs/GrowthCircle_Sponsor_Toolkit_v12.zip)"
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    # Ensure Python ≥3.6
    if sys.version_info < (3, 6):
        log.error("Python 3.6 or higher is required.")
        sys.exit(1)

    src = args.source.resolve()
    out = args.output.resolve()
    excludes = [
        src / "docs",
        src / ".git",
        src / ".venv",
        src / "venv",
        src / "__pycache__",
        src / "node_modules",
    ]

    bundle_toolkit(src, out, excludes)
