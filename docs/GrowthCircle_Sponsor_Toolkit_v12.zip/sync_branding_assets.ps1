# sync_branding_assets.ps1
# Syncs branding assets to GitHub Pages folder and pushes them live

Write-Host "`n🔄 Syncing branding assets to GitHub Pages…" -ForegroundColor Cyan

# Ensure destination folder exists
New-Item -ItemType Directory -Force -Path ".\docs\Branding" | Out-Null

# Copy all files from Branding into GitHub Pages directory
Copy-Item ".\Branding\*" ".\docs\Branding\" -Recurse -Force

# Stage files for Git
git add docs/Branding/*

# Commit with timestamp for tracking
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$commitMessage = "Sync branding assets — $timestamp"
git commit -m $commitMessage

# Push to master
git push origin master

Write-Host "`n✅ Branding assets synced and pushed successfully!" -ForegroundColor Green
