#!/usr/bin/env python3
"""
fetch_and_serve.py

1) (Optional) Fetch a remote ZIP (e.g. your full toolkit) and extract it locally
2) Serve a directory over HTTP on localhost
3) Optionally expose it via ngrok

Usage:
  python fetch_and_serve.py \
    [--fetch-zip https://…/GrowthCircle_Sponsor_Toolkit.zip] \
    [--dir docs] \
    [--port 8000] \
    [--no-ngrok]
"""

import argparse
import sys
import threading
import webbrowser
import zipfile
import shutil
import tempfile
from pathlib import Path
from http.server import HTTPServer, SimpleHTTPRequestHandler

# third-party imports
try:
    import requests
except ImportError:
    print("Error: requests is required. Install with `pip install requests`", file=sys.stderr)
    sys.exit(1)

try:
    from pyngrok import ngrok
    NGROK_AVAILABLE = True
except ImportError:
    NGROK_AVAILABLE = False


def fetch_and_extract(zip_url: str, target_dir: Path):
    """Download ZIP from zip_url and extract into target_dir (wiping it first)."""
    print(f"📥 Downloading ZIP from {zip_url} …")
    resp = requests.get(zip_url, stream=True)
    resp.raise_for_status()

    # Write to a temp file
    with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as tmp_zip:
        for chunk in resp.iter_content(1024 * 1024):
            tmp_zip.write(chunk)
    print("🗜 Extracting ZIP …")
    # Clean target_dir
    if target_dir.exists():
        shutil.rmtree(target_dir)
    target_dir.mkdir(parents=True)

    with zipfile.ZipFile(tmp_zip.name, 'r') as zf:
        zf.extractall(target_dir)
    print(f"✅ Extracted to {target_dir}")
    # Remove temp zip
    Path(tmp_zip.name).unlink()


def serve_directory(directory: Path, port: int):
    """Start a simple HTTP server serving 'directory' on 'port'."""
    os_cwd = Path.cwd()
    try:
        # Change into the serve directory
        import os
        os.chdir(directory)
        handler = SimpleHTTPRequestHandler
        server = HTTPServer(("0.0.0.0", port), handler)
        sa = server.socket.getsockname()
        print(f"🌐 Serving {directory} at http://{sa[0]}:{sa[1]}")
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n🔌 Server interrupted, shutting down.")
    finally:
        os.chdir(os_cwd)


def main():
    parser = argparse.ArgumentParser(description="Fetch, extract, and serve your sponsor toolkit.")
    parser.add_argument(
        "--fetch-zip", "-f",
        help="Remote ZIP URL to download and extract before serving"
    )
    parser.add_argument(
        "--dir", "-d",
        type=Path,
        default=Path("docs"),
        help="Local directory to serve (default: ./docs)"
    )
    parser.add_argument(
        "--port", "-p",
        type=int,
        default=8000,
        help="Local HTTP port (default: 8000)"
    )
    parser.add_argument(
        "--no-ngrok",
        action="store_true",
        help="If set, do not open an ngrok tunnel even if pyngrok is installed"
    )
    args = parser.parse_args()

    # Step 1: Fetch & extract ZIP if requested
    if args.fetch_zip:
        fetch_and_extract(args.fetch_zip, args.dir)

    # Validate serve directory
    if not args.dir.exists() or not args.dir.is_dir():
        print(f"Error: serve directory not found: {args.dir}", file=sys.stderr)
        sys.exit(1)

    # Step 2: Launch HTTP server in background thread
    server_thread = threading.Thread(
        target=serve_directory,
        args=(args.dir.resolve(), args.port),
        daemon=True
    )
    server_thread.start()

    # Auto-open browser to root
    webbrowser.open(f"http://localhost:{args.port}/")

    # Step 3: Open ngrok tunnel if available
    if not args.no_ngrok:
        if NGROK_AVAILABLE:
            public_tunnel = ngrok.connect(args.port, bind_tls=True)
            print(f"🔗 ngrok tunnel established at: {public_tunnel.public_url}")
        else:
            print("⚠️  pyngrok not installed; skipping ngrok tunnel.")

    # Keep main thread alive until server stops
    try:
        server_thread.join()
    except KeyboardInterrupt:
        print("👋 Exiting.")

if __name__ == "__main__":
    main()
