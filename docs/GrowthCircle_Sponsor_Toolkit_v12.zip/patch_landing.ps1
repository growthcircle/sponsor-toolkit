param($RepoPath = "C:\Users\devuser\Sponsor_Toolkit")

Push-Location $RepoPath

# 1) Define the new snippet
$newSection = @"
<!-- Sponsor Deck CTA -->
<section class="cta">
  <h2>Download the Sponsor Deck</h2>
  <a class="button" href="Pitch_Deck/Growth_Circle_Sponsor_Deck.pdf" download>
    <img src="Screenshots/glide_admin_dashboard.png" alt="Deck Preview" class="thumbnail"/>
    Download PDF
  </a>
</section>

<!-- Flyers Preview -->
<section class="flyers">
  <h2>QR Flyers</h2>
  <div class="flyer-grid">
    <a href="Branded_Flyers/GC_QR_Flyer_Portrait.pdf" download>
      <img src="Branded_Flyers/QR_Preview_PNGs/qr_Portrait.png" alt="Portrait Flyer" class="thumbnail"/>
      Portrait
    </a>
    <a href="Branded_Flyers/GC_QR_Flyer_WhiteLabel.pdf" download>
      <img src="Branded_Flyers/QR_Preview_PNGs/qr_WhiteLabel.png" alt="White Label Flyer" class="thumbnail"/>
      White Label
    </a>
  </div>
</section>

<!-- Full Toolkit ZIP -->
<section class="cta">
  <h2>Download Full Toolkit</h2>
  <a class="button" href="GrowthCircle_Sponsor_Toolkit.zip" download>
    <img src="Screenshots/zip_icon.png" alt="ZIP Preview" class="thumbnail"/>
    Download ZIP
  </a>
</section>

<!-- Glide Dashboard Preview -->
<section class="dashboard">
  <h2>Live Dashboard</h2>
  <a href="https://growthcircle.glide.page" target="_blank">
    <img src="Screenshots/glide_admin_dashboard.png" alt="Glide Dashboard" class="thumbnail"/>
    Open Dashboard
  </a>
</section>
"@

# 2) Inject it into docs/index.html (replace the old content between <!-- START ASSETS --> markers)
(Get-Content docs/index.html) `
  -replace '(?s)<!-- START ASSETS -->.*?<!-- END ASSETS -->', "<!-- START ASSETS -->`r`n$newSection`r`n<!-- END ASSETS -->" `
  | Set-Content docs/index.html

# 3) Commit & push
git add docs/index.html
git commit -m "Enhance landing page: fix links, add thumbnails & CTAs"
git push origin master

Pop-Location
